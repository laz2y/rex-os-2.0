const path = require("path");

// Server-side credentials live in backend/.env (gitignored) or in the host
// process environment — never in frontend code or VITE_* variables.
require("dotenv").config({ path: path.join(__dirname, ".env") });

// Optional gitignored credential override (backend/.auth-secrets.json).
// Service/auth values fill gaps when the process environment lacks them; the
// password hash always overrides so the rotated credential wins. Never
// committed, never sent to the browser.
try {
  const secrets = require(path.join(__dirname, ".auth-secrets.json"));
  if (secrets) {
    const GAP_KEYS = [
      "REX_USERNAME",
      "JWT_SECRET",
      "PORTAINER_URL",
      "PORTAINER_API_TOKEN",
      "PORTAINER_ENDPOINT_ID",
      "JELLYFIN_URL",
      "JELLYFIN_API_KEY",
      "NEXTCLOUD_URL",
      "NEXTCLOUD_USERNAME",
      "NEXTCLOUD_PASSWORD",
      "IMMICH_URL",
      "IMMICH_API_KEY",
      "QBITTORRENT_URL",
      "QBITTORRENT_USERNAME",
      "QBITTORRENT_PASSWORD",
    ];
    for (const key of GAP_KEYS) {
      if (
        typeof secrets[key] === "string" &&
        secrets[key].length > 0 &&
        !process.env[key]
      ) {
        process.env[key] = secrets[key];
      }
    }
    if (
      typeof secrets.REX_PASSWORD_HASH === "string" &&
      secrets.REX_PASSWORD_HASH.length > 0
    ) {
      process.env.REX_PASSWORD_HASH = secrets.REX_PASSWORD_HASH;
    }
  }
} catch {
  /* no override file — fall back to the process environment */
}

const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");

const systemRoute = require("./routes/system");
const dockerRoute = require("./routes/docker");
const jellyfinRoute = require("./routes/jellyfin");
const nextcloudRoute = require("./routes/nextcloud");
const immichRoute = require("./routes/immich");
const authRoute = require("./routes/auth");

const app = express();

// Reflect the calling origin so the session cookie works cross-origin too.
app.use(
  cors({
    origin: (origin, callback) => callback(null, origin || true),
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());

// Production: serve the built frontend (../dist) from the same process so a
// single `node server.js` hosts both the REX OS UI and the /api backend.
// Registered before the JSON root route so / serves the app shell in
// production; guarded so it is skipped when dist/ is absent (pure API).
const distDir = path.join(__dirname, "..", "dist");
const fs = require("fs");
if (fs.existsSync(distDir)) {
  // Real files (assets, index.html, favicon) win; then the SPA fallback
  // serves the app shell for unknown non-/api GET paths.
  app.use(express.static(distDir));
  app.use((req, res, next) => {
    if (req.method !== "GET" || req.path.startsWith("/api")) {
      return next();
    }
    res.sendFile(path.join(distDir, "index.html"));
  });
  console.log(`🖥️  Serving REX OS UI from ${distDir}`);
}

// API-only mode (no dist/): the root returns API info. In production the
// static block above already answered / with the app shell, so this route
// is only reachable when the UI build is absent.
app.get("/", (req, res) => {
  res.json({
    app: "REX API",
    version: "2.0.0",
    status: "online",
  });
});

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    version: "2.0.0",
    uptime: process.uptime(),
  });
});

app.use("/api/system", systemRoute);
app.use("/api/docker", dockerRoute);
app.use("/api/jellyfin", jellyfinRoute);
app.use("/api/nextcloud", nextcloudRoute);
app.use("/api/immich", immichRoute);
app.use("/api/auth", authRoute);

app.listen(process.env.PORT || 4000, () => {
  console.log(
    `🚀 REX API running on port ${process.env.PORT || 4000}`
  );
});